project_files <- c(
  file.path("R", "results_io.R"),
  file.path("R", "compress_results.R"),
  file.path("R", "semiparametric_mediation.R"),
  file.path("R", "run_simulations.R"),
  file.path("R", "run_comparator.R"),
  file.path("R", "test_comparator_outputs.R"),
  file.path("R", "run_calibrated_power.R"),
  file.path("R", "test_calibrated_power_outputs.R"),
  file.path("R", "run_variance_sensitivity.R"),
  file.path("R", "test_variance_sensitivity.R"),
  file.path("R", "run_confounding_simulation.R"),
  file.path("R", "run_confounding_application.R"),
  file.path("R", "test_confounding_sensitivity.R"),
  file.path("R", "test_confounding_outputs.R"),
  file.path("R", "run_confounding_curve.R"),
  file.path("R", "test_confounding_curve.R"),
  file.path("R", "test_confounding_curve_outputs.R"),
  file.path("R", "run_application.R"),
  file.path("R", "validate_outputs.R"),
  file.path("R", "test_effect_map.R"),
  file.path("R", "test_application.R"),
  file.path("R", "paired_fit_audit.R"),
  file.path("R", "make_manuscript_assets.R"),
  file.path("data", "jobs.RData"),
  "manuscript.tex",
  "supplement.tex"
)
missing_files <- project_files[!file.exists(project_files)]
if (length(missing_files)) {
  stop(
    "Run this script from the repository root containing run_all.R. Missing: ",
    paste(missing_files, collapse = ", ")
  )
}

run_r_script <- function(path) {
  message("\n==> ", path)
  status <- system2(file.path(R.home("bin"), "Rscript"), path)
  if (!identical(status, 0L)) {
    stop(path, " failed with status ", status)
  }
}

run_r_script(file.path("R", "check_dependencies.R"))

reuse_results <- Sys.getenv("JKSS_REUSE_RESULTS", unset = "0") == "1"
if (reuse_results) {
  message("Reusing retained simulation and application results without refitting.")
} else {
  if (Sys.getenv("JKSS_SKIP_SIMULATIONS", unset = "0") != "1") {
    run_r_script(file.path("R", "run_simulations.R"))
    run_r_script(file.path("R", "run_calibrated_power.R"))
    run_r_script(file.path("R", "run_variance_sensitivity.R"))
    run_r_script(file.path("R", "run_confounding_simulation.R"))
    run_r_script(file.path("R", "run_confounding_curve.R"))
  } else {
    message("Skipping simulations because JKSS_SKIP_SIMULATIONS=1.")
  }
  run_r_script(file.path("R", "run_application.R"))
  run_r_script(file.path("R", "run_confounding_application.R"))
}
run_r_script(file.path("R", "test_effect_map.R"))
run_r_script(file.path("R", "test_calibrated_power.R"))
run_r_script(file.path("R", "summarize_calibrated_power.R"))
run_r_script(file.path("R", "test_calibrated_power_outputs.R"))
run_r_script(file.path("R", "make_calibrated_power_assets.R"))
run_r_script(file.path("R", "test_variance_sensitivity.R"))
run_r_script(file.path("R", "test_confounding_sensitivity.R"))
run_r_script(file.path("R", "summarize_confounding.R"))
run_r_script(file.path("R", "test_confounding_outputs.R"))
run_r_script(file.path("R", "make_confounding_assets.R"))
run_r_script(file.path("R", "test_confounding_curve.R"))
run_r_script(file.path("R", "summarize_confounding_curve.R"))
run_r_script(file.path("R", "test_confounding_curve_outputs.R"))
run_r_script(file.path("R", "make_confounding_curve_assets.R"))
run_r_script(file.path("R", "test_application.R"))
run_r_script(file.path("R", "validate_outputs.R"))
run_r_script(file.path("R", "test_comparator_outputs.R"))
run_r_script(file.path("R", "paired_fit_audit.R"))
run_r_script(file.path("R", "make_manuscript_assets.R"))
Sys.setenv(JKSS_VARIANCE_ASSETS_ONLY = "1")
run_r_script(file.path("R", "run_variance_sensitivity.R"))
Sys.unsetenv("JKSS_VARIANCE_ASSETS_ONLY")

dir.create(file.path("tmp", "pdfs"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("output", "pdf"), recursive = TRUE, showWarnings = FALSE)

compile_latex <- function(tex_file, output_name) {
  latexmk <- Sys.which("latexmk")
  pdflatex <- Sys.which("pdflatex")
  if (nzchar(latexmk)) {
    status <- system2(
      latexmk,
      c(
        "-pdf",
        "-interaction=nonstopmode",
        "-halt-on-error",
        "-outdir=tmp/pdfs",
        tex_file
      )
    )
  } else if (nzchar(pdflatex)) {
    args <- c(
      "-interaction=nonstopmode",
      "-halt-on-error",
      "-output-directory=tmp/pdfs",
      tex_file
    )
    status <- 0L
    for (iteration in seq_len(3L)) {
      status <- system2(pdflatex, args)
      if (!identical(status, 0L)) break
    }
  } else {
    stop("No latexmk or pdflatex found; install TeX before rebuilding the PDFs.")
  }

  if (!identical(status, 0L)) {
    stop("LaTeX compilation failed for ", tex_file)
  }
  built_pdf <- file.path(
    "tmp", "pdfs", paste0(tools::file_path_sans_ext(basename(tex_file)), ".pdf")
  )
  # Preserve the LaTeX PDF; rewriting it can corrupt embedded font subsets.
  copied <- file.copy(
    built_pdf,
    file.path("output", "pdf", output_name),
    overwrite = TRUE
  )
  if (!copied) stop("Could not copy compiled PDF: ", built_pdf)
  top_level_pdf <- paste0(tools::file_path_sans_ext(basename(tex_file)), ".pdf")
  if (!file.copy(built_pdf, top_level_pdf, overwrite = TRUE)) {
    stop("Could not refresh the top-level PDF: ", built_pdf)
  }
  invisible(TRUE)
}

compile_latex("manuscript.tex", "JKSS_manuscript.pdf")
compile_latex("supplement.tex", "JKSS_supplement.pdf")

run_r_script(file.path("R", "compress_results.R"))

archive_files <- c(
  "README.md",
  "UPLOAD_GUIDE_KO.md",
  "CITATION.cff",
  "THIRD_PARTY_NOTICES.md",
  ".gitignore",
  ".gitattributes",
  "APPLICATION_JOBS2_20260916.md",
  "VARIANCE_SENSITIVITY_PLAN_20260916.md",
  "CONFOUNDING_SENSITIVITY_PLAN_20260916.md",
  "CURVE_SIMULATION_PLAN_20260916.md",
  "POWER_CALIBRATION_PLAN_20260923.md",
  "Makefile",
  "run_all.R",
  "manuscript.tex",
  "supplement.tex",
  "confounding_section.tex",
  "confounding_application_section.tex",
  "confounding_supplement.tex",
  "confounding_curve_section.tex",
  "confounding_curve_supplement.tex",
  "calibrated_power_supplement.tex",
  list.files("docs", recursive = TRUE, full.names = TRUE),
  list.files(file.path("output", "pdf"), pattern = "^JKSS_.*\\.pdf$", full.names = TRUE),
  list.files("data", full.names = TRUE),
  list.files("R", full.names = TRUE),
  list.files("results", full.names = TRUE),
  list.files("figures", full.names = TRUE)
)
archive_files <- sort(archive_files[file.info(archive_files)$isdir %in% FALSE])
archive_path <- file.path(
  "output", "JKSS_Online_Resource_2_reproducibility.zip"
)
if (file.exists(archive_path) && !file.remove(archive_path)) {
  stop("Could not replace the existing reproducibility archive.")
}
utils::zip(archive_path, archive_files, flags = "-r9X")
if (!file.exists(archive_path) || file.info(archive_path)$size == 0) {
  stop("The reproducibility archive was not created.")
}

message("\nReproduction workflow and Online Resource 2 archive completed.")
