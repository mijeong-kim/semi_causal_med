# Variance-misspecification sensitivity: frozen design

Specified before the new Monte Carlo results were examined, 2026-09-16.
This experiment does not change the proposed estimator, its tuning parameters,
the existing simulations, or the empirical example.

- Sample size: 300; 500 attempted replications per configuration.
- Innovations: Gaussian and the standardized asymmetric mixture already defined
  in `R/semiparametric_mediation.R`. Independent innovations for the two equations.
- Baseline X is standard normal; T is independent Bernoulli(0.5).
- Conditional means and population natural effects are those of the main study:
  M = 0.2 + 0.4 T + 0.3 X + eM;
  Y = 0.5 T - 0.8 M + T M + 0.4 X + eY.
- Both errors are independent innovations multiplied by the same scale s(T,X).
  Covariate mechanism: s^2 = exp(kappa X - kappa^2/2).
  Treatment mechanism: s^2 = exp(kappa (2T-1))/cosh(kappa).
  Each mechanism has E(s^2)=1, so changing heterogeneity does not change marginal
  error variance. Scales are population-normalized, not sample-normalized.
- Kappa = 0, 0.15, 0.30, 0.60. The kappa=0 configuration is shared, not counted
  twice. Six nonconstant-variance configurations plus one reference per density.
- Independent structural innovations and randomized T preserve sequential
  ignorability in this construction. The experiment violates the statistical
  independent-error restriction, not the causal identification assumptions.
- Methods: unchanged density-score estimator and OLS with the existing stacked
  empirical sandwich (HC0-type) and empirical baseline-mean contribution.
- Seed: 20260917, with stored independent task seeds. A replication reuses X, T,
  and innovations across the seven configurations (common random numbers).
- Report all five effects: bias and MCSE, RMSE, empirical SD, mean reported SE,
  interval coverage and MCSE, interval length, numerical success and MCSE, and
  the all-attempted report-and-cover fraction. Also report paired successful-fit
  comparisons so differing numerical success does not change comparison samples.
- No failure replacement, trimming, bandwidth tuning, or selection of favorable
  configurations. Report adverse results. This finite experiment cannot prove
  robustness or validate the assumptions in the JOBS II illustration.

There are 7,000 generated configurations and 14,000 attempted method fits.
At coverage 0.95 with 500 successful fits, the binomial MCSE is about 0.0097;
it is larger when some fits fail. No journal submission is authorized by this file.
