# JKSS 자료 업로드 안내

이 폴더는 `mijeong-kim/semi_causal_med`를 갱신할 때 사용하는 JKSS 원고용
스냅샷입니다. 원격 저장소와의 최종 동기화 여부는 업로드 전 `git status`와
최근 커밋에서 확인합니다.

## 용량을 줄인 버전

큰 CSV 13개를 무손실 `.csv.gz`로 바꾸어 `results` 용량을 약 60MB에서
17MB로 줄였습니다. 결과 행이나 숫자의 정밀도를 줄인 것은 아닙니다.
R 코드는 압축 파일을 직접 읽으므로 압축을 풀지 않아도 됩니다.

**`results/`뿐 아니라 수정된 `R/`, `run_all.R`, `Makefile`도 함께 올려주세요.**
이미 같은 이름의 원래 `.csv`를 GitHub에 올렸다면, 이번에 압축한 파일에
대해서만 기존 `.csv`를 `.csv.gz`로 교체해야 중복 용량이 남지 않습니다.
교체 대상 13개는 `docs/RESULT_COMPRESSION.csv`에 있습니다.
작은 요약 CSV와 표 파일은 그대로 유지합니다.

## 올릴 자료

`github_JKSS` 폴더 자체를 저장소 안에 중첩하기보다, **이 폴더 안의 내용**을
저장소 최상위에 배치하면 README와 실행 명령을 그대로 사용할 수 있습니다.

- `README.md`, `Makefile`, `run_all.R`: 설명과 실행 명령
- `R/`, `data/`, `results/`, `figures/`: 코드, 예제 데이터, 전체 결과, 그림
- 최상위 `.tex` 파일 전체: 본문과 보충자료의 편집 가능한 소스
- `output/pdf/`: 최신 본문과 보충자료 PDF
- `docs/`, 실험계획 `.md`, `CITATION.cff`, 데이터 출처 안내
- `.gitignore`, `.gitattributes`: 숨김 파일이므로 함께 포함

커버레터, 심사의견, 이전 원고, 임시 파일, 별도 이분산성 연구와 R 패키지는
이 폴더에 포함하지 않았습니다. 코드 및 데이터의 이용 조건은
`THIRD_PARTY_NOTICES.md`를 참고하세요.

## 기존 파일을 보존하면서 교체하기

기존 저장소를 새 작업 폴더로 복제하고 별도 브랜치에서 작업하는 편이 안전합니다.
아래는 직접 업로드할 때 사용할 예시이며, 여기서는 실행하지 않았습니다.

```sh
git clone https://github.com/mijeong-kim/semi_causal_med.git semi_causal_med_JKSS_upload
cd semi_causal_med_JKSS_upload
git switch -c jkss-submission
rsync -av --exclude='.git/' --exclude='tmp/' --exclude='output/*.zip' ../github_JKSS/ ./
git status --short
git diff --stat
```

위 명령은 `0_mediation`에서 시작하는 것을 가정합니다. 복사 명령에는
`--delete`를 넣지 않았으므로 기존 파일을 일괄 삭제하지 않습니다.
따라서 이전 연구에만 필요한 파일이 남는지 확인하고, 필요하면 별도 보관 후
새 브랜치에서만 정리하세요. 과거 버전은 기존 브랜치와 커밋 이력에 남습니다.

검토 후 다음 명령으로 새 브랜치에 올릴 수 있습니다.

```sh
git add .
git diff --cached --stat
git commit -m "Prepare JKSS manuscript reproducibility materials"
git push -u origin jkss-submission
```

이 명령은 기본 브랜치를 바로 덮어쓰지 않습니다. GitHub에서 변경 내용을
확인한 뒤 기본 브랜치에 반영하고, 논문과 일치하는 커밋이나 릴리스를 기록하세요.

## 실행 확인

먼저 `README.md`의 R 패키지를 설치한 뒤 저장소 최상위에서 실행합니다.

```sh
Rscript R/check_dependencies.R
make smoke
make validate
JKSS_REUSE_RESULTS=1 Rscript run_all.R
```

마지막 명령은 저장된 결과로 표·그림·PDF·재현 ZIP을 다시 만듭니다.
`Rscript run_all.R`만 실행하면 전체 시뮬레이션을 다시 수행하므로 오래 걸립니다.
검증 시 실제로 실행한 범위는 `docs/VERIFICATION.md`에 기록합니다.

개별 분석을 다시 실행한 뒤 큰 CSV가 생성되면 `make compact`로 다시
압축할 수 있습니다. 이 명령은 압축본을 복원해 원본과 일치하는지 확인한
다음에만 중복된 큰 CSV를 제거합니다.
