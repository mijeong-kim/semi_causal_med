# Snapshot Verification

Verified locally on 2026-09-30 using R 4.6.1 on macOS (arm64).
These are checks of the supplied JKSS snapshot, not a new full Monte Carlo run.

## Executed Checks

`make smoke validate` completed successfully from the new `github_JKSS` root
on 2026-09-29.
It also passed again after replacing the 13 large CSV files with compressed
copies. No manual extraction was performed for that validation run.

On 2026-09-30, `JKSS_REUSE_RESULTS=1 Rscript run_all.R` passed again after
the supplement reorganization. The main, comparator, paired-fit, calibrated-power,
variance-sensitivity, confounding, full-curve and application checks used the
retained full outputs; no full Monte Carlo rerun was performed.

| Check | Result |
| --- | --- |
| Required R packages | Available in the validation environment |
| Lossless compression, gzip reading and fresh-CSV precedence | Passed |
| All five estimators and both total-effect decompositions | Passed |
| Effect-map derivatives and baseline-mean propagation | Passed |
| JOBS II data, baseline terms and application diagnostics | Passed |
| Huber coefficients, covariance, shift invariance and calibration | Passed |
| Independent calibrated-power output validation | Passed |
| Main simulation and application output validation | Passed |
| Comparator seeds, summaries and representative OLS refits | Passed |
| Variance-misspecification output validation | Passed |
| Confounding-sensitivity algebra, gradients and output | Passed |
| Full-curve population identities, covariance and output | Passed |

The main validation checked 16,000 attempted method fits (15,807 valid).
The comparator validation checked 20,000 attempted method fits (19,940 valid),
all 4,000 data-set seeds and 100 summary cells. The largest discrepancy in the
16 reconstructed comparator OLS fits was 4.89e-15. Variance sensitivity checked
14,000 attempts (13,792 valid); confounding sensitivity checked 6,000 attempts
(5,997 valid), with the full-curve analysis using those same data sets.

Two supplementary Huber checks emitted `quantreg` warnings that an intermediate
quantile-regression solution may be nonunique. All assertions passed; warnings
were not treated as evidence of a failed check.

## Environment

| Package | Loaded version |
| --- | --- |
| Matrix | 1.7.5 |
| rootSolve | 1.8.2.4 |
| sn | 2.1.3 |
| mediation | 4.5.1 |
| medflex | 0.6.11 |
| quantreg | 6.1 |

For this local check, `sn` was loaded from a pre-existing auxiliary R library
through `R_LIBS`; it was not installed in the default library. No library or
machine-specific path is bundled. Other users should install the dependencies
listed in `README.md`, then run `Rscript R/check_dependencies.R`.

## File Checks

- All 39 R files, including the runner and compression helpers, parsed.
- All 42 distinct LaTeX input/figure paths resolved across 33 TeX files.
- The citation file parsed as YAML and identifies an unpublished manuscript.
- The included `jobs` object exactly matched `mediation` version 4.5.1.
- The original snapshot passed a byte-identical comparison of 92 scientific
  source, study-data, numerical-output and manuscript/PDF files. The compact
  revision preserves the scientific inputs and numeric values; 18 CSV-reading
  entry points now use a shared plain/gzip reader. The 2026-09-29 theory update
  leaves the score equations and all reported finite-sample tuning values
  unchanged while expressing numerical safeguards as convergent sequences.
- Every compressed file was restored and checked for MD5 equality before its
  redundant CSV was removed. All 13 uncompressed hashes also match the original
  records in `Latex/JKSS/results`; see `RESULT_COMPRESSION.csv`.
- The revised theory and algorithm pages of both supplied PDFs were rendered
  and visually checked.
- The supplement now follows the manuscript in ten sections. All 16 tables
  and six figures are retained; main-text cross-references match the new
  numbering. Revised simulation, calibration, sensitivity and application pages
  were rendered and checked. LaTeX reported no undefined references or box warnings.
- All 47 CSV/RDS numerical files in the primary manuscript's results directory
  remained byte-identical across the document rebuild.
- Figure 4 was redrawn from the 25 retained JOBS II estimates with a separate
  legend panel and wider legend-column spacing. The standalone figure and its
  manuscript page were rendered and checked; estimates and intervals were unchanged.
- Supplement Section S10 was shortened to a repository link, archive provenance
  and essential reproduction commands. The rebuilt PDF's GitHub hyperlink was
  checked, and the final page was rendered and visually inspected.
- The main-text contribution statements and interpretive prose were revised for
  positive or neutral framing. Theoretical scope, assumptions, numerical results
  and adverse findings were retained; shared supplementary prose was synchronized.
  Both PDFs were recompiled and revised pages were rendered for layout checks.
- Repeated interpretation was consolidated in the main article, with the
  supplement retaining derivations, computational details and complete tables.
  Duplicate variance-sensitivity and full-curve findings paragraphs were removed
  from the supplement. Numbered equations, propositions, numerical files and all
  figure/table assets were preserved; both PDFs and cross-references were checked.
- No cover letters, build logs, local R libraries or temporary checkpoints
  were included. The retained data and PDFs are not excluded by `.gitignore`.

`FILE_MANIFEST.csv` records relative paths, byte sizes and MD5 hashes of the
delivered snapshot, excluding the manifest itself. It is an integrity inventory,
not a package lockfile or cryptographic authenticity claim. Regenerating tables,
figures or validation reports can change hashes; the inventory describes the
current local submission snapshot only. It does not certify a remote GitHub upload.

## Rebuild Scope

The complete Monte Carlo experiments and application analyses were not refitted.
All retained-output validators were rerun, however, and
`JKSS_REUSE_RESULTS=1 Rscript run_all.R` recompiled both PDFs and rebuilt the
reproducibility ZIP from the stored full results. No GitHub upload or release
was performed by this local verification step.
